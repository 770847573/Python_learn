import  calendar

# 打印某个月份的万年历
# print(calendar.month(2020,8))
# 打印某一年的万年历
# print(calendar.calendar(2020))
# 判断某年是否是闰年
print(calendar.isleap(2021))       # ******