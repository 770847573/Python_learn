def func():
    print("ccc")

def func1():
    print("ccc~~~~111")

def func2():
    print("ccc~~~~222")
def func3():
    print("ccc~~~~333")