def func():
    print("aaaaa")

num = 10