def func():
    print("bbbbb")

num = 20